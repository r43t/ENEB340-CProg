/* new binary search program of an integer array */
#include <stdio.h>
#include <stdlib.h>

void bubble_sort(int[],int);
int binary_search(int[],int,int);
	
int main(void)
{
	int num[100], i, count, key, loc;

	for(count=0;count<100;count++) {
		printf("Enter a number (0 to exit): ");
		if (scanf("%d",&num[count])==EOF)
			break;
		if (num[count]<=0)
			break;
	}
	if (!count) exit(1);
	
	for(i=0;i<count;i++)
	   printf("%c %d",i%10?' ':'\n',num[i]);
	bubble_sort(num,count);
	for(i=0;i<count;i++)
	   printf("%c %d",i%10?' ':'\n',num[i]);
	printf("\nEnter a key: ");
	scanf("%d",&key);
	loc=binary_search(num,count,key);
	if (loc==-1)
	   printf("Error: key was not found\n");
	else
	   printf("Key found in position %d\n",loc);
	return 0;
}

int binary_search(int num[],int count, int key)
{
   int low=0, high=count-1, middle;
   while (low<=high) {
      middle=(low+high)/2;
      if (key > num[middle])
         high=middle-1;
      else if (key < num[middle])
         low=middle+1;
      else
         return middle;
   }
   return -1;
}

void bubble_sort(int num[], int count)
{
   int temp, i, j;
   for(j=0;j<count-1;j++)
      for(i=j+1;i<count;i++)
         if(num[i]>num[j]) 
            temp=num[i], num[i]=num[j], num[j]=temp;
   return;
}




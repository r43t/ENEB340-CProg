/* Program #12.1, last modified Oct. 7, 2019
	This is a simple demonstration of pointers 
       Written by Wes Lawson*/
#include <stdio.h>

int main(void)
{
  int count=5;
  int *count_ptr=&count;

  printf("for count    , rvalue=%d; lvalue=%p\n",count,count_ptr);
  printf("for count    , rvalue=%d; lvalue=%x\n",*count_ptr,&count);
  printf("for count    , rvalue=%d; lvalue=%x\n",*&count,&*count_ptr);
  printf("for count_ptr, rvalue=%p; lvalue=%x\n",count_ptr,&count_ptr);
  return 0;
}

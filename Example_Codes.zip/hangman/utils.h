#ifndef HANGMAN_UTILS_H
#define HANGMAN_UTILS_H

#include <stdlib.h>

/*
 Prints the hangman ascii art
 */
void print_hangman(int tries_left);

#endif //HANGMAN_UTILS_H

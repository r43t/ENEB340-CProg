#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main()
{
  srand(time(NULL));   // Initialize the RNG, should only be called once.
  int r;

  while (1) {
    /* random int between 0 and 19 */
    r = rand() % 20;
    printf("%d ", r);
    }
  return 0;
}


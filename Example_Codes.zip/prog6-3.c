#include <stdio.h>
#include <stdlib.h>
#include <string.h>  // more on this later

int main(int argc, char *argv[])
{
  char buff[BUFSIZ], temp[2];
  int value,i,j,multiplier;  //  value is now an integer
  void color_lookup(int);
  double resistor=0, correction=1; 

  printf("Enter Resistor Value: ");
  //gets(buff); 
  fgets(buff, sizeof(buff), stdin);
  value=strlen(buff)-1;  // finds the number of characters in the string
  //printf("strlen: %d\n", value);
  for (i=0;i<value;i++) {
    temp[0]=buff[i];
    temp[1]='\0';
    //printf("%c\n", temp[0]);
  
  switch (temp[0]) {
    case '0': case '1': case '2': case '3': case '4': 
    case '5': case '6': case '7': case '8': case '9': 
    resistor=10.0*resistor+atof(temp);
    //printf("%f\n", resistor);
    break;

    case 'k': case 'K':
    resistor*=1000.;
    break;

    case 'M':
    resistor *=1000000.;
    break;

    case ',':
    break;  // ignore

    case '.':
    for (j=i+1;j<value;j++){
    if ((buff[j]>='0')&&(buff[j]<='9'))
      correction/=10.;	}
    break;

    default:
    printf("illegal character entered");
    return (1);
    }
   //printf("%f\n", resistor);
  }

  resistor*=correction;
  //printf("%f\n", resistor);

  for(multiplier=-1;resistor>=10.;multiplier++)
    resistor/=10.;

  for(i=0;i<2;i++) {
    if (buff[i]>='0'&&buff[i]<='9')
      color_lookup(buff[i]-'0');
    else if (buff[i]=='.' && buff[i+1]>='0' && buff[i+1]<='9')
      color_lookup(buff[i+1]-'0');
    else
      color_lookup(0);
  }

  color_lookup(multiplier);
  //printf("%d\n", multiplier);
  printf("\n");
  return 0;
}

/* print color from table -  same function as from Program 6.2 */
void color_lookup(int i)
{
  switch(i) {
    case -1: printf("Gold ");
    break;
    case 0: printf("Black ");
    break;
    case 1: printf("Brown ");
    break;
    case 2: printf("Red ");
    break;
    case 3: printf("Orange ");
    break;
    case 4: printf("Yellow ");
    break;
    case 5: printf("Green ");
    break;
    case 6: printf("Blue ");
    break;
    case 7: printf("Violet ");
    break;
    case 8: printf("Grey ");
    break;
    case 9: printf("White ");
    break;
    }
  return;
}

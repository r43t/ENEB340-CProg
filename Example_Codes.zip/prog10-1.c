/* new bubble sort program of an integer array */
#include <stdio.h>
#include <stdlib.h>

void bubble_sort(int[],int);
	
int main(void)
{
    int num[100], i, count;
    for(count=0;count<100;count++) {
	    printf("Enter a number: ");
	    if (scanf("%d",&num[count])==EOF) 
  	        break;
  	    if (num[count]<=0)
			break;
        }
	
    if (!count) exit(1);
  	    
    // print array before we start to sort
    printf("\n\nThe unsorted array is:\n");
    for(i=0;i<count;i++)
    	printf("%c %d",i%10?' ':'\n',num[i]);
    bubble_sort(num,count);
    	
    // finished sort high to low; print results
    printf("\n\nThe SORTED array is:\n");
    for(i=0;i<count;i++)
    	printf("%c %d",i%10?' ':'\n',num[i]);
    printf("\n\n");
    
    return 0;
}

void bubble_sort(int num[], int count)
{
   int temp, i, j;
   for(j=0;j<count-1;j++)
      for(i=j+1;i<count;i++)
         if(num[i]>num[j]) 
            temp=num[i], num[i]=num[j], num[j]=temp;
   return;
}



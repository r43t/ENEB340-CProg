/* trajectory program 
Written by W. Lawson 5 Oct 2019*/
#include <stdio.h>
#include <math.h>
#define GRAVITY 9.81
#define PI 3.141592654

int main (void)
{
	double dist(double,double),time(double,double),height(double,double);
	double theta, velocity;
	const double thcnv=PI/180.;
	printf("Enter initial velocity (m/s): "), scanf("%lf",&velocity);
	printf("Enter initial angle (degrees): "), scanf("%lf",&theta);
	theta*=thcnv;
	printf("Maximum distance = %f m\n",dist(velocity,theta));
	printf("Maximum   time   = %f s\n",time(velocity,theta));
	printf("Maximum  height  = %f m\n",height(velocity,theta));
	return 0;
}

double dist (double velocity, double theta)
{
	return (velocity*velocity*sin(2*theta)/GRAVITY);
}
double time (double velocity, double theta)
{
	return (2.0*velocity*sin(theta)/GRAVITY);
}
double height (double velocity, double theta)
{
	return (velocity*velocity*sin(theta)*sin(theta)/2.0/GRAVITY);
}

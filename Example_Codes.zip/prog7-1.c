/* Selection Sort */

#include <stdio.h>

int main()
{
  int num[100], i, j, temp, count;

  //  input all of the integers that we are going to sort
  for(count=0;count<100;count++) {
    printf("Enter an integer # %i (0 to exit): ",count+1);
    if (scanf("%d",&num[count])==EOF)
      break;
    if (num[count]<=0)
      break;
    }

  // print array before we start to sort
  printf("\n\nThe unsorted array is:\n");
  for(i=0;i<count;i++)
    printf("%c %d",i%10?' ':'\n',num[i]);
    
  // sort
  for(j=0;j<count-1;j++) {
    for(i=j+1;i<count;i++)
      if(num[i]>num[j]) {
        temp=num[i];
        num[i]=num[j];
        num[j]=temp;
        }
     } 

  // finished sort high to low; print results
  printf("\n\nThe SORTED array is:\n");
  for(i=0;i<count;i++)
    printf("%c %d",i%10?' ':'\n',num[i]);
  printf("\n\n");
  return 0;
}


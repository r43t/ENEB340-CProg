/* calculate roots of quadratic equation 
Written by W. Lawson
Last modified 28 September 2019*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(void)
{
  char buff[BUFSIZ];
  double a, b, c, div, descr, r1;
  
  printf("Enter Value for Coefficient 'a': ");
  //gets(buff);
  fgets(buff, sizeof(buff), stdin);
  a=atof(buff);
  printf("Enter Value for Coefficient 'b': ");
  //gets(buff);
  fgets(buff, sizeof(buff), stdin);
  b=atof(buff);
  printf("Enter Value for Coefficient 'c': ");
  //gets(buff);
  fgets(buff, sizeof(buff), stdin);
  c=atof(buff);
  
  if (a==0)
    if (b==0) {
      printf("Invalid data...goodbye\n");
      exit(0);
      }
   else
      printf("Only one solution for x= %g\n",-c/b);
  else {
    div=2.*a;
    descr=b*b-4.*a*c;
    if (descr >= 0) {
      printf("Roots are real\n");
      printf("Root1 = %g\n",(-b+sqrt(descr))/div);
      printf("Root2 = %g\n",(-b-sqrt(descr))/div);
      }
    else {
      r1=sqrt(-descr)/div;
      printf("Roots are complex\n");
      printf("Root1 = (%g)+i(%g)\n",-b/div,r1);
      printf("Root2 = (%g)-i(%g)\n",-b/div,r1);
      }
    }
  return 0;
}


/* example #02 electric field calculation
* Written by W. Lawson
* Version 1.3 Last updated Sept 22, 2019 */

#include <stdio.h>
#define CHARGE -1.602e-19 /* new feature */ 
#define EPSILON_0 8.854e-12
#define PI 3.141592654

int main(void) 
{
  float e_field, radius=.0025; /*new feature */ 
  e_field=CHARGE/(4.0*PI*EPSILON_0*radius*radius); 
  printf("Electric field at a radius %f = %f\n",radius,e_field); /* this printf has more than one argument */

  return 0;  
}



#include <stdio.h>

int main(void) {

  struct LIST {
  int data;
  struct LIST *back;
  struct LIST *next;} l1;

  struct LIST *ptr=&l1;
	
  /*
  ptr->data=12;
  // equivalent to (*ptr).data=12;
  ptr->back=ptr;
  ptr->next=ptr->back;
  */
	
  l1.data=12;
  l1.back=&l1;
  l1.next=l1.back;
	
  printf("%d  %p %p \n", l1.data, l1.back, ptr->next);
  return (0);
}




#include <stdio.h>
#include <string.h>

int main() {
  int len=0, i, j;
  char str[20];
  char str2[20];
  char str3[20];

  fgets(str, 20, stdin);
  for(int i=0; str[i]!= '\n'; i++) {
    str2[i]=str[i];
    len++;
    }
  str[len] = '\0';
  str2[len] = '\0';
  printf("str: %s\n", str);
  printf("str2: %s\n", str2);

  for(i= 0, j=0; str[i]!= '\0'; i++) {
    if(str[i] != ' ') {
      str2[j]=str[i];
      j++;
      }
    }
  str2[j] = '\0';

  printf("str2: %s\n", str2);
}


/* Program #12.3, last modified Oct. 12, 2019
	This is a simple demonstration of a linked list 
	Written by Wes Lawson
	Last updated 1 Dec 2020*/
	
#include <stdio.h>
/* This structure contains one integer datum 
  and has pointers to the next and previous values */
  
  struct LIST {
  int data;
  struct LIST *back;
  struct LIST *next;
  };


/* This function inserts a new datum in a linked list sorted low to high */
void insert(int k, struct LIST list[]) {
  int j;
  struct LIST *NEXT, *LAST;

  /* Find lowest value in the list */
  for (j=0;j<k;j++){
    if (list[j].back==NULL){
      NEXT=&list[j];
      break;
      }
    }

  /* Find where the new value fits in the list */
  for (j=0;j<k;j++) {
    if (list[k].data>NEXT->data) {
      LAST=NEXT;
      NEXT=NEXT->next;
      }
    else
      break;
    }

  if (j==0) {
  /* value is smallest in the list */
    list[k].next=NEXT;
    NEXT->back=&list[k];
    }
  else {
    if (j<k) {
      /* value is neither the smallest nor the largest */
      list[k].next=NEXT;
      list[k].back=LAST;
      NEXT->back=LAST->next=&list[k];
      }
    else {
      /* value is the largest in the list */
      list[k].back=LAST;
      LAST->next=&list[k];
      }
    }
  return;
}

/* This function prints the linked list sorted low to high */
void print(int i, struct LIST list[]) {
/* Find lowest value in the list */
  int j;
  struct LIST *Next;

  for (j=0;j<i;j++){
    if (list[j].back==NULL) {
      Next=&list[j];
      break;
      }
    }
  
  /* Print sorted list */
  for (j=0;j<i;j++) {
    printf("%c %d",j%8?' ':'\n',Next->data);
    Next=Next->next;
    }
  printf("\n");
  return;
}

int main(void) {
  /* create a maximum list of 100 */
  struct LIST list[100];
  struct LIST *Next;
  int i=0,j,temp;

  /* read in new values and sort them on the go */
  printf("Enter positive integers (negative int to exit):\n");
  while (i<99) {
    scanf("%d",&temp);
    if (temp<0)
      break;
    list[i].data=temp;
    list[i].back=NULL;
    list[i].next=NULL;
 
    if (i>0)
      insert(i,list);
    i++;
    print(i,list);
    }
  return (0);
}

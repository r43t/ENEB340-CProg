/* factorial program */
#include <stdio.h>
#include <stdlib.h>

int main (void)
{
   double factorial (double);
   int n;
   char buff[BUFSIZ];
	while(1) {
		printf("Enter Value for n: ");
		fgets(buff, sizeof(buff), stdin);
		n=atoi(buff);
		if (n<1)
			break;
		printf("%d ! = %14.6g\n",n,factorial(n));
	}
	return 0;
}


double factorial (double n)
{
   if (n>1)
      return (n*factorial(n-1));
   else
      return 1.;
}

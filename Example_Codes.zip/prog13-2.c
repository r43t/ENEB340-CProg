/* write, append, and read values of sin(x) to disk */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <math.h>
#define PI 3.1415927

int main( void )
{
  FILE *f1, *fp1, *fp2;
  double count, temp_sin ;

  /* write sin(x) from 0 to PI/2 */
  if( (f1 = fopen( "sine.dat" , "w")) == NULL) {
    printf("Error cannot open file sine.dat for writing....." ) ;
    exit( EXIT_FAILURE ) ;
    }

  for( count = 0 ; count < PI/2 ; count += 0.01 ) {
    if( fprintf( f1 , "Sine of %6.3g radians = %8.6g\n" , count, sin( count )) ==EOF) {
      printf("Error writing out file sine.dat..... ") ;
      exit( EXIT_FAILURE ) ;
      }
    }

  if( fclose(f1) )
    printf("Errr Closing File sine.dat.....") ;

  /* append sin(x) from PI/2 to PI */
  if( (f1 = fopen( "sine.dat" , "a")) == NULL) {
    printf("Error cannot open file sine.dat for appending....." ) ;
    exit( EXIT_FAILURE ) ;
    }

  for( count = PI/2 ; count < PI ; count += 0.01 ) {
    if( fprintf( f1 ,"Sine of %6.3g radians = %8.6g\n", count, sin( count )) ==EOF) {
      printf("Error appending out file sine.dat..... ") ;
      exit( EXIT_FAILURE ) ;
      }
    }

  if( fclose(f1) )
    printf("Error Closing File sine.dat.....") ;

  /* read and print sin(x), cos(x) and tan(x) from 0 to PI (to another file)*/
  if( (fp1 = fopen("sine.dat" , "r")) == NULL ) {
    printf("Error opening File sine.dat..... ") ;
    exit( EXIT_FAILURE ) ;
    }

  if( (fp2 = fopen("sctan.dat" , "w")) == NULL ) {
    printf("Error opening File sctan.dat .....") ;
    exit( EXIT_FAILURE ) ;
    }

  while(1) {
    if( fscanf( fp1, "Sine of %lf radians = %lf\n" , &count, &temp_sin) != 2)
      break ;
    if( fprintf( fp2,"%f %f %f %f\n", count, temp_sin, cos(count), tan(count)) == EOF )
      break ;
    }  

  if( ferror(fp1) )
    printf("Error Reading File sine.dat.....") ;

  if( fclose(fp2) )
    printf("Error Writing to File sctan.dat.....") ;

  return 0 ;
}

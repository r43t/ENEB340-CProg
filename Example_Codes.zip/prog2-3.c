/* example #03 calculates the resistance of two parallel resistors Written by W. Lawson
Version 1.5 Last modified 9/22/2019
More appropriate argument for exit() function */ 

#include <stdio.h>
#include <stdlib.h> /* includes info on exit() */ 

int main(void) 
{
   float r1, r2, r3;
   printf("Enter the resistance values `r1' and `r2': ");
   
   if (scanf("%f %f",&r1, &r2) != 2) { /* two numbers read? */
      printf("Data entered incorrectly...Bye!!\n");
      exit(1); 
      }

   if (r1!=0) { /* check to insure resistance r1 isn't zero */
      if (r2!=0) { /* check to insure resistance r2 isn't zero */ 

      r3=1.0/(1.0/r1+1.0/r2);
	printf("Total resistance r3 = %f ohms\n",r3);
      } 
   
      else {
         printf("r2 is a short circuit...\n"); /* end of if-else test */
         exit(1);
      }
   }
   else
     printf("r1 is a short circuit...\n"); /* end of if-else test */

   return 0; 
}

#include <stdio.h>

#define SWAP(T, a, b) {T tmp=a; a=b; b=tmp;}

int main()
{
  int x=1, y=2;
  printf("x=%d, y=%d\n", x, y);  
  SWAP(int, x, y);
  printf("x=%d, y=%d\n", x, y);  
  return 0;
}

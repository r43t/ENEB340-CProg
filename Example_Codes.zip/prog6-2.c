/* print out resistor color code 
Written by W. Lawson
Last modified 29 September 2019 */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
  char buff[BUFSIZ];
  double value;
  int i,multiplier;
  void color_lookup(int);

  printf("Enter Resistor Value: ");
  //gets(buff); 
  fgets(buff, sizeof(buff), stdin);
  value=atof(buff);

  for(multiplier=-1;value>=10.;multiplier++)
    value=value/10.;

  for(i=0;i<2;i++) {
    if (buff[i]>='0'&&buff[i]<='9')
      color_lookup(buff[i]-'0'); // Get first color band
    else if (buff[i]=='.' && buff[i+1]>='0' && buff[i+1]<='9')
      /* get second color band; if the resistance is an integer
      second band must be black */
      color_lookup(buff[i+1]-'0');
    else
      color_lookup(0); // add black – integer resistance
      }
    color_lookup(multiplier); // Find the third color band 
  printf("\n");
  return 0;
}

/* print color from the table */
void color_lookup(int i)
{
  switch(i) {
    case -1: printf("Gold ");
    break;
    case 0: printf("Black ");
    break;
    case 1: printf("Brown ");
    break;
    case 2: printf("Red ");
    break;
    case 3: printf("Orange ");
    break;
    case 4: printf("Yellow ");
    break;
    case 5: printf("Green ");
    break;
    case 6: printf("Blue ");
    break;
    case 7: printf("Violet ");
    break;
    case 8: printf("Grey ");
    break;
    case 9: printf("White ");
    break;
    }
  return;
}


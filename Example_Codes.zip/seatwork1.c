#include <stdio.h>

int main()
{
  int len;
  char str[20];
  char str2[20];

  // TODO
  // get user input
  // count string length
  
  printf("Len: %d\n", len);)	


  // TODO: Copy str to str2, display str2

  // TODO: Remove any space in str and store into str2, display str2

  // TODO: Convert str to all uppercase, display the resulting string

  // TODO: Compare str and str2, indicate whether equal or not
 
  // TODO: Get a string input, determine if the string is a palindrome. Note: convert the string to lowercase, remove non-alphanumeric characters
  
  return 0;
}


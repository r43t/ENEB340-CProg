#include <stdio.h>
#include <string.h>

int main()
{
  char str[20];

  printf("Enter a string: ");
  //scanf("%s\n", str);
  fgets(str, sizeof(str), stdin);
  //gets(str);

  // if using fgets, remove trailing '\n'
  str[strlen(str)-1]='\0';
  printf("sizeof(str): %lu, strlen(str): %lu\n", sizeof(str), strlen(str));
  printf("String: %s\n", str);

  return 0;
}

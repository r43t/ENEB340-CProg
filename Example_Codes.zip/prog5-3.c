/* example #5.3  bitwise operation examples 
Written by W. Lawson First written Sept 28, 2019 */

#include <stdio.h>

int main(void)
{
  unsigned char a=181, b=108, i;
  printf(“a=%d   b=%d  i=%d\n”,a,b,i);
  printf(" a&b = %d\n",a&b);
  printf(" a|b = %d\n",a|b);
  printf(" a^b = %d\n",b^=a);
  printf("  ~a = %d\n",(unsigned char)~a);
  printf("a<<i = %d\n",(unsigned char)(a<<i));
  printf("a>>i = %d\n",a>>=i);
  return 0;
}


/* Program 13.1 calculates the resistance of two parallel resistors */
/* by calling the function rtot. 	                   
     Written by Wes Lawson
     Last modified 8 Oct 2019*/

#include <stdio.h>
#include <stdlib.h>    /* includes info on exit()  */

int main(void)
{
  FILE *f1, *f2;
  float r1, r2, r3;
  float rtot(float, float);        /* function prototype  */ 

  f1=fopen("test_in","r");         /* open input file     */
  f2=fopen("test_out","w");        /* open output file    */

  if ((f1==NULL)||(f2==NULL)) {
    printf("Error opening files...Bye!!\n");
    exit(0);
    }
  if (fscanf(f1,"%f %f",&r1, &r2)!=2) {  /* two numbers read? */
    printf("Data entered incorrectly...Bye!!\n");
    exit(0);
    } 

   fprintf(f2,"total Resistance Rtot = %f ohms\n",rtot(r1,r2));
   fclose(f1);
   fclose(f2);
   printf("Program ran successfully...Bye!!\n");
   return 0;
}

/* check to insure neither resistance is zero,
    then calculate parallel combination         */
float rtot(float r1, float r2)
{
  float r3;
  
  if ((r1==0)||(r2==0))
    r3=0.0;
  else
    r3=1.0/(1.0/r1+1.0/r2);
  return r3;
}


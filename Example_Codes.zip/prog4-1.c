/* 
determine size of data types in bytes
written by W. Lawson
last modified 27 Sept 2019 
*/

#include <stdio.h> 
int main(void)
{
  char name1[5], prompt[]="Enter the second name:"; 
  int test=20;
  printf("Size of character:\t%lu\n",sizeof(char)); 
  printf("Size of short int:\t%lu\n",sizeof(short int)); 
  printf("Size of integer:\t%lu\n",sizeof(int));
  printf("Size of long int:\t%lu\n",sizeof(long int)); 
  printf("Size of real:\t\t%lu\n",sizeof(float));
  printf("Size of double:\t\t%lu\n",sizeof(double)); 
  printf("Size of long double:\t%lu\n",sizeof(long double)); 
  printf("Size of name1:\t\t%lu\n",sizeof(name1)); 
  printf("Size of prompt:\t\t%lu\n",sizeof(prompt)); 
  printf("Size of test:\t\t%lu\n",sizeof(test));
  return 0; 
}

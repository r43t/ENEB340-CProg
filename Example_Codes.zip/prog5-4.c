#include <stdio.h>

int main()
{
  int width = 10, length = 20;
  float radius = 2.5, height = 10;
  double pi = 3.1416;

  printf("%f %d \n", (float)width*length, sizeof(width*length));
  printf("%f %u \n", radius*radius, sizeof(pi*radius*radius));
  printf("%f\n", 2*pi*height*radius);
  printf("%f\n", height*width*length);
  printf("%f\n", height*radius*radius*pi);

  return 0;
}


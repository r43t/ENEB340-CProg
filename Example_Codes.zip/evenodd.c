#include <stdio.h>

int main()
{
  int n=0;
  
  printf("Enter n: ");
  scanf("%d", &n);
 
  if (n%2==0) printf("n is even.\n");
  else printf("n is odd.\n"); 
  
  return 0;
}


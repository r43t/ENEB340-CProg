/* Program #1: Demonstrates simple print command*/
/* Written by W. Lawson*/
/* First written Aug 15, 1997; last modified Sept 22, 2019 */ 

#include <stdio.h> 	/* will explain this later */

int main(void) 		/* all programs must have a main */
{
  printf("ENEB 340 is my favorite class"); /* 1st line */ 
  printf("Prof. Lawson is a ... teacher\n");   /* 2nd line */

  return 0; /* end */
}

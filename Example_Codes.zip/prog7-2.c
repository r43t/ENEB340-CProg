/*		Frequency response
 		Written by W. Lawson
 		Written 30 Oct 2014
Last modified 3 Oct 2019  */

#include <stdio.h>
#include <math.h>
#define PI 3.141592654

/* A program to evaluate the voltage divider rule for an RL circuit as a function
   of frequency with linear and nonlinear increments */

int main(void)
{
  int i=0, num_freq;
  double r, ind, freq, temp, freq_min, freq_max, vrat, freqlin, vratlin;

  printf("enter resistance (ohms)"), scanf("%lf",&r);
  printf("enter inductance (mH)"), scanf("%lf",&ind);
  ind/=1000.;
  printf("enter minimum frequency (kHz)"), scanf("%lf",&freq_min);
  printf("enter maximum frequency (kHz)"), scanf("%lf",&freq_max);
  printf("enter number of frequency points"), scanf("%d",&num_freq);
  printf("\nFrequency (kHz)   \tVoltage Ratio\n\n");
  printf("\n\n\n      Nonlinear Spacing \t\t       Linear spacing\n\n");
		
  while (i<num_freq) {
    //nonlinear spacing
   freq=freq_min*pow(freq_max/freq_min,(float)i/(num_freq-1));
   temp=2.*PI*freq*ind;
   vrat=temp/sqrt(r*r+temp*temp);

    //linear spacing
    freqlin=freq_min+(freq_max-freq_min)*i/(num_freq-1);
    temp=2.*PI*freqlin*ind;
    vratlin=temp/sqrt(r*r+temp*temp);

    //print results
    printf(" %f \t %f \t\t %f \t %f\n",freq,vrat,freqlin,vratlin);
    i++;
    }
  return 0;
}



#include <stdio.h>
#include <stdlib.h>

int main()
{
  int x=0;

  printf("%d\n", ++x);
  printf("%d\n", ++x);

  return 0;
}

/*  
Read a string and convert it to a character 
written by W. Lawson
last modified 27 Sept 2019     */

#include <stdio.h>

int main (void)
{
  int ATOI(char[]);
  char test[BUFSIZ];
  printf("Enter a number: ");
  //fgets(test, sizeof(test), stdin);		
  scanf("%s", test);
  printf("\nString %s, sizeof = %lu", test, sizeof(test));
  printf("\nATOI %d, sizeof = %lu\n", ATOI(test), sizeof(ATOI(test)));
  return 0;
}

/* converts numeric string to an integer */
int ATOI (char s[])
{
  int i, j=0, ISDIGIT(char);
  for (i=0;ISDIGIT(s[i]);i++)
    j=10*j+(s[i]-'0');
  return j;
}

int ISDIGIT(char c)
{
  return ((c>=0x30)&&(c<0x39));
}



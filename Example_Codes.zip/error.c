#include <stdio.h>

int main()
{
int x=10, sum=0;
if (x > 0) {
 	sum = sum + x;
 	printf("greater than zero\n");
        }
else
 	printf("less than zero\n");
return 0;
}

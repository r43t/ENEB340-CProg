#include <stdio.h>
#include <string.h>

int main()
{

char str[20];
printf("Enter string: ");
scanf("%s", str);

int n = 0;
int flag = 0;
char str5[] = "hello world";
printf("Len: %d", strlen(str));

while(str[n] != '\0' && str5[n]!=0){
if(str[n] != str5[n]){
printf("%c %c \n", str[n], str5[n]);
flag = 1;
//break;
}
else
n++;
}
if(flag == 0){
printf("\nThe strings are equal\n");
}
else{
printf("\nThe strings are not equal\n");
}

return 0;
}

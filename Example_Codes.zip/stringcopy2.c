#include <stdio.h>
#include <string.h>

int main()
{

  char str1[20];
  char str2[20];
  printf("Enter string1: ");
  scanf("%s", str1);
  printf("Enter string2: ");
  scanf("%s", str2);

  int n = 0, maxlen = 0;
  int flag = 0;
  printf("Len: %lu %lu", strlen(str1), strlen(str2));

  for (n=0; str1[n]!='\0'; n++) {
    if (str1[n]!=str2[n]) {
      flag=1;
      break;
    }
  }

  if (str1[n]=='\0' && str2[n]!='\0') flag=1;

  if (flag == 0) {
    printf("\nThe strings are equal.\n");
    }
  else {
    printf("\nThe strings are not equal.\n");
    }

  return 0;
}

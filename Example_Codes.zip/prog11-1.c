/* Written by Wes Lawson
Last updated 7 Oct 2019 */
#include <stdio.h>
#define PI 3.141592654f

int main(void) { /*demonstrates advanced formatting */
  int i;
  char test[]="Hi World";
  
  for (i=1;i<16;i++) {
    printf("%*s %+0*f\t\t",i,test,i,PI);
    printf("%.*s %+0.*f\n",i,test,i,PI);
    }
  return 0;
}

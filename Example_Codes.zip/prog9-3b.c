#include <stdio.h>

void target(int *y)
{
  *y = 10;
  printf("In target: %d\n",*y );
}

void main(void)
{
  int x = 3;
  printf("In main: %d\n",x );
  target(&x);/* at this point, simulated pass by reference** leaves x set to 10*/
  printf("In main: %d\n", x );
}


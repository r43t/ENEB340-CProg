/* Program 2.2. Read a string and convert it to a character 
     written by W. Lawson
     last modified 27 Sept 2019     */
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int ISDIGIT(char c);
int ATOI (char s[]);

int main (void)
{
	char test[BUFSIZ];
	puts("enter a number");
	scanf("%s", test);
	printf("\n%s = %d\n",test,ATOI(test));
	return 0;
}

/* true if character is 0 - 9; false otherwise */
int ISDIGIT(char c)
{
	return ((c>=0x30)&&(c<0x39));
}

/* converts numeric string to an integer */
int ATOI (char s[])
{
	int i, j=0, ISDIGIT(char);
	for (i=0;ISDIGIT(s[i]);i++)
		j=10*j+(s[i]-'0');
	return j;
}




/* example #5.2 determine the result of floating point inaccuracies
Written by W. Lawson. First written Sept 28, 2019 */ 

#include <stdio.h>
int main(int argc, char *argv[])
{
  float x1=1./3., x2, x3, y1=2.e33, y3=2.e33, y5; 
  double y2=2.e300, y4, x4=1./3., x5, x6; 

  x2=x3=x5=x6=1./3.;
  y5=1.-(x1+x2+x3);
  y4=1.-(x4+x5+x6);
  printf("Roundoff error? \t 0 = %g = %g \n",y4, y5);

  y5=1./(y1*y2);
  printf("underflow error? \t 0.25e-333 = %g\n",y5); y5=y1*y2;
  printf("overflow error? \t 4.e333 = %g\n",y5); y5=1./(y1*y3);
  printf("underflow error? \t 0.25e-66 = %g\n",y5); y5=y1*y3;
  printf("overflow error? \t 4.e66 = %g\n",y5);

  return 0; 
}

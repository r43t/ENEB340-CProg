/* program to calculate array statistics */
#include <stdio.h>
#include <stdlib.h>

void bubble_sort(int[],int);
int mean(int num[], int count);
int mode(int num[], int count);

int main(void)
{
    int num[100], count;
    for(count=0;count<100;count++) {
    	printf("Enter a number (0 to exit): ");
    	if (scanf("%d",&num[count])==EOF)
    		break;
        if (num[count]<=0)
    		break;
    	    }
    
    if (!count) exit(1);	
    bubble_sort(num,count);
    printf("Array maximum = %d \n",num[0]);
    printf("Array minimum = %d \n",num[count-1]);
    printf("Array median = %d \n",num[count/2]);
    printf("Array mean = %d \n",mean(num,count));
    printf("Array mode = %d \n",mode(num,count));
    return 0;
}

void bubble_sort(int num[], int count)
{
   int temp, i, j;
   for(j=0;j<count-1;j++)
      for(i=j+1;i<count;i++)
         if(num[i]>num[j]) 
            temp=num[i], num[i]=num[j], num[j]=temp;
   return;
}

int mean(int num[], int count)
{
	int avg=0, i;
	for(i=0;i<count;avg+=num[i++]);
	return (avg/count);
}

int mode(int num[], int count)
{
	int i=0, omode=0, nmode, otemp, ntemp;
	while (i<count-1) {
		ntemp=num[i];
		for(nmode=1;i<(count-1)&&ntemp==num[++i];nmode++);
		if (nmode>omode) {
			otemp=ntemp;
			omode=nmode;
		}
	}
	printf("frequency = %d \n",omode);
	return otemp;
}




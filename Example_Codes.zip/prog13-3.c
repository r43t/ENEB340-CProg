/* perform a bubble sort of an integer array from high to low*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  FILE *File_in, *File_out;
  int num[100], i, j, temp, count=0;

  // input all of the integers that we are going to sort
  if( (File_in = fopen( argv[1] , "r")) == NULL) {
    perror("Error cannot open file for reading....." ) ;
    exit( EXIT_FAILURE ) ;
    }

  while( 1 ) {
    if( fscanf( File_in, "%i\n" , &temp) != 1)
      break ;
    num[count++]=temp;
    }

  // print array before we start to sort
  printf("\n\nThe unsorted array is:\n");
  for(i=0;i<count;i++)
    printf("%c %d",i%10?' ':'\n',num[i]);

  // sort
  for(j=0;j<count-1;j++) {
    for(i=j+1;i<count;i++)
      if(num[i]>num[j]) {
        temp=num[i];
        num[i]=num[j];
        num[j]=temp;
        }
      }

  if( fclose( File_in ) )
    perror("Error closing file .....") ;

  if( (File_out = fopen( argv[2] , "w")) == NULL) {
    perror("Error cannot open file for writing....." ) ;
    exit( EXIT_FAILURE ) ;
    }

  // finished sort high to low; print results
  printf("\n\nThe SORTED array is:\n");
  fprintf(File_out,"\n\nThe SORTED array is:\n");
  for(i=0;i<count;i++) {
    printf("%c %d",i%10?' ':'\n',num[i]);
    fprintf(File_out,"%c %d",i%10?' ':'\n',num[i]);
    } 
  printf("\n\n");

  if( fclose( File_out ) )
    perror("Error closing file.....") ;

  return 0;
}

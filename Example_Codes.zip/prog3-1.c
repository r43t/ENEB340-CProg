#include <stdio.h>

int main(void) 
{
  float x, exp_x, term; int n,yes_no;
  
  do {
    printf("Please enter a value to calculate: "); scanf("%f",&x);
    n=1, exp_x=1, term=1;
    while (n<100) { 
      term=(x/n)*term; exp_x=exp_x+term; n=n+1;
      } 

  printf("x=%f\texp(x)=%f\n\n",x,exp_x);
  printf("Do you wish to compute another exponential? [1=yes 0=no] "); 
  scanf("%d",&yes_no);

  if (yes_no!=0) yes_no=1;
  } while(yes_no==1);
  
  return 0; 
}


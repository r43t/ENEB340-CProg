#include <stdio.h>

int main()
{
  int k;

  for (k=0; k<=12, k++) {
    printf("ok ");
    }

  return 0;
}

/* example #05 input four names and compare */
#include <stdio.h>
#define STRL 5 /* BUFSIZE could also be used, which is a
symbolic constant #DEFINEd in stdio.h */

int main(void) 
{
  char name1[STRL], name2[STRL], name3[STRL], name4[STRL]; char prompt[]="Enter the second name:";
  int i, test=0;

  puts("Enter the first name:");
  //gets(name1); /* entry method 1 */ 
  fgets(name1, sizeof(name1), stdin);
  
  for(i=0;prompt[i]!='\0';i++)
    putchar(prompt[i]);
  putchar('\n');

  for(i=0;(name2[i]=getchar())!='\n';i++); /* entry method 2 */ 
    name2[i]='\0';

  printf("Enter the third name:\n");
  scanf("%s",&name3[0]); /* entry method 3 */ 
  
  printf("Enter the final name:\n");
  scanf("%s",name4); /* entry method 4 */

  puts(name1); 
  puts(name2); 
  puts(name3);
  puts(name4); 

  for (i=0;(i<STRL)&&((name1[i]!='\0')||(name4[i]!='\0'));i++) 
    test+=(name1[i]!=name4[i]);

  printf("%s is",name1); if (test)
  printf(" not");
  printf(" the same as %s\n",name4);

  return 0;   
}

/*
demonstration of storage classes 
written by W. Lawson
last modified 27 Sept 2019     
*/

#include <stdio.h>

int i=10, j=5, k=5;   // global variables

int main(int argc, char *argv[])
{
  int l, func(int);

  printf("main: i=%d\t j=%d\t k=%d\t l=%d\n",i,j,k,l);
  func(i);
  l=func(j);
  printf("main: i=%d\t j=%d\t k=%d\t l=%d\n",i,j,k,l);
  return 0;
}

int func (register int i)
{
  auto int j=i+4, l;
  static int k;

  printf("func: i=%d\t j=%d\t k=%d\t l=%d\n",i++,j++,k++,l++);
  return k;
}


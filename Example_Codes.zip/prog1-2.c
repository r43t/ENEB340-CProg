#include <stdio.h>
#include "prog1-2.h"

int main()
{
  printf("Value of pi: %f\n", PI);
  return 0;
}



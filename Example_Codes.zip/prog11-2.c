#include <stdio.h>
/************************************************
 *                                              *
 * Demonstration of scanf formatting            *
 *                                              *
 * History : Date      Reason                   *
 *           12/01/14  Created  by W. Lawson    *
 *                                              *
 ************************************************/
int main(int argc, char *argv[])
{
  char name[80];
  int test=10;

  printf("Input a string after each prompt\n\n");
  printf("First, an unformatted scanf\n\n");
  scanf("%s",name);
  printf("Result: %s\n\n",name);
  fflush(stdin);
  printf("Now, with: scanf(\" %[^\\n] \",name);\n\n");
  scanf("%[^\n]",name);
  printf("Result: %s\n\n",name);
  fflush(stdin);
  printf("Now, with: scanf(\" %[^a-z] \",name);\n\n");
  scanf("%[^a-z]",name);
  printf("Result: %s\n\n",name);
  fflush(stdin);
  printf("Now, with: scanf(\" %[a-z WL] \",name);\n\n");
  scanf("%[a-z WL]",name);
  printf("Result: %s\n\n",name);
  fflush(stdin);
  printf("Now, with: scanf(\" %[a-zWL] \",name);\n\n");
  scanf("%[a-zWL]",name);
  printf("Result: %s\n\n",name);
  fflush(stdin);
  printf("Now, with: scanf(\" %%*s, %%i \"&test);\n\n");
  //scanf("%*s, %i",&test);
  scanf("%*s %i",&test);
  printf("Result: %i\n\n",test);
  fflush(stdin);

  return 0;
}


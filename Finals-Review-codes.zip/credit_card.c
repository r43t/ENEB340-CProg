#include <stdio.h>

struct credit_card {
  char name[32];
  unsigned long long number;
  char expiry[16];
  char type[16];
  char bank[16];
  char provider[16];
  };

int main(void)
{
  struct credit_card usoft = {
  "Bill Gates",
  7007123455558001,
  "12/25/2010",
  "Platinum",
  "Citibank",
  "Visa"
  };

  puts(usoft.name);
  printf("%llu\n",usoft.number);
  puts(usoft.expiry);
  puts(usoft.type);
  puts(usoft.bank);
  puts(usoft.provider);
  printf("Sizeof(struct credit_card) = %lu bytes\n", sizeof(struct credit_card));
}

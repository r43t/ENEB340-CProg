#include <stdio.h>

struct date {
  int month;
  int day;
  int year;
  };

struct credit_card {
  char name[32];
  unsigned long long number;
  struct date expiry; /* date structure */
  char type[16];
  char bank[16];
  char provider[16];
};

int main(void)
{
  struct credit_card pguy= {
  "Nobill Nogates",
  7007123455558001,
  { 2,1,2005 }, /* month, day, year */
  "Silver",
  "Rural Bank",
  "Diners"
  };

  struct date newdate = {5, 1, 2015};
  pguy.expiry = newdate;

  puts(pguy.name);
  printf("%llu\n",pguy.number);
  printf("%d/%d/%d\n", pguy.expiry.month, pguy.expiry.day, pguy.expiry.year);
  puts(pguy.type);
  puts(pguy.bank);
  puts(pguy.provider);
}

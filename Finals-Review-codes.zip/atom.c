#include <stdio.h>
#include "atom.h"

atom_t create_atom(int proton, int electron)
{
  atom_t temp;
  temp.proton = proton;
  temp.electron = electron;
  return temp;
}

void show_atom(atom_t element)
{
  printf("%d electrons, %d protons\n", element.electron, element.proton);
}

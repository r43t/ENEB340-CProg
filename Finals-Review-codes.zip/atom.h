#ifndef __ATOM_H__
#define __ATOM_H__

typedef struct {
  int electron;
  int proton;
  } atom_t;

atom_t create_atom(int proton, int electron);
void show_atom(atom_t element);
void mix_atom(atom_t element1, atom_t element2);

#endif /* __ATOM_H__ */

#include <stdio.h>
#include "atom.h"

/* create_atom() is implemented in another file/module */
int main(void)
{
  atom_t carbon, hydrogen;
  hydrogen = create_atom(1, 1);
  carbon = create_atom(6, 6);

  printf("Carbon has ");
  show_atom(carbon);
  printf("Hydrogen has ");
  show_atom(hydrogen);

  return 0;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void fix_fgets(char str[])
{
  str[strlen(str)-1] = '\0';
}

int main(void) 
{
int i = 0;
int vote;

struct candidate {
  char name[80];
  int votes;
  };

struct candidate cand1;
struct candidate cand2;

printf("Enter cand1 name: ");
fgets(cand1.name, 80, stdin);
fix_fgets(cand1.name);
cand1.votes = 0;

printf("Enter cand2 name: ");
fgets(cand2.name, 80, stdin);
fix_fgets(cand2.name);
cand2.votes = 0;

printf("\nVote now: (1 for candidate 1, 2 for candidate 2)\n");
while(i<9) {
  scanf("%d", &vote); 
  if (vote==1) cand1.votes++;
  else if (vote==2) cand2.votes++;
  i++;
  }

if (cand1.votes > cand2.votes) printf("%s wins!!!\n", cand1.name);
else printf("%s wins!!!\n", cand2.name);
}

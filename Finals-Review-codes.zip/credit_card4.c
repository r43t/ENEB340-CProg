#include <stdio.h>

struct date {
  int month;
  int day;
  int year;
  };

struct credit_card {
  char name[32];
  unsigned long long number;
  struct date expiry; /* date structure */
  char type[16];
  char bank[16];
  char provider[16];
};

int isExpired(struct credit_card a, struct date today)
{
  if (a.expiry.year > today.year)  
    return 0;
  else if (a.expiry.year < today.year)
    return 1;

  /* a.expiry.year == today.year */
  if (a.expiry.month > today.month)
    return 0;
  else if (a.expiry.month < today.month)
    return 1;

  /* a.expiry.month == today.month */
  if (a.expiry.day < today.day)
    return 1;

  return 0;
}

int main(void)
{
  struct credit_card pguy= {
  "Nobill Nogates",
  7007123455558001,
  { 2,1,2005 }, /* month, day, year */
  "Silver",
  "Rural Bank",
  "Diners"
  };

  puts(pguy.name);
  printf("%llu\n",pguy.number);
  printf("%d/%d/%d\n", pguy.expiry.month, pguy.expiry.day, pguy.expiry.year);
  puts(pguy.type);
  puts(pguy.bank);
  puts(pguy.provider);

  struct date testday = { 1, 1, 2008 };

  if (isExpired(pguy, testday))
    printf("The card of %s is expired.\n", pguy.name);

}

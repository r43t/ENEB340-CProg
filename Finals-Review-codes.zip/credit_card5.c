#include <stdio.h>

struct date {
  int month;
  int day;
  int year;
  };

typedef struct date date_t;

typedef struct credit_card {
  char name[32];
  unsigned long long number;
  struct date expiry; /* date structure */
  char type[16];
  char bank[16];
  char provider[16];
} credit_card_t;

int main(void)
{
  credit_card_t pguy= {
  "Nobill Nogates",
  7007123455558001,
  { 2,1,2005 }, /* month, day, year */
  "Silver",
  "Rural Bank",
  "Diners"
  };

  date_t newdate = {5, 1, 2015};
  pguy.expiry = newdate;

  puts(pguy.name);
  printf("%llu\n",pguy.number);
  printf("%d/%d/%d\n", pguy.expiry.month, pguy.expiry.day, pguy.expiry.year);
  puts(pguy.type);
  puts(pguy.bank);
  puts(pguy.provider);
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
  struct credit_card {
    char  name[32];		/* 32 bytes  */
    unsigned long long number; 	/* 8 bytes */
    char expiry[16];		/* 16 bytes */
    char type[16];		/* 16 bytes */
    char bank[16];		/* 16 bytes */
    char provider[16];		/* 16 bytes */
    };

struct credit_card rulers[ ] = {
            { "Bill Gates" },
            { "Larry Ellison" },
            { "Michael Dell" }
        };

int i;
for(i=0; i<sizeof(rulers)/sizeof(rulers[0]); i++)
    puts(rulers[i].name);

printf("sizeof(ruler[0]): %d\n", sizeof(rulers[0]));

}
